insert into categoria (id, nombre)values (nextval('categoria_seq'), 'Categoria 1');
insert into categoria (id, nombre)values (nextval('categoria_seq'), 'Categoria 2');
insert into categoria (id, nombre)values (nextval('categoria_seq'), 'Categoria 3');
insert into producto(id,nombre,pvp)values(nextval('producto_seq'),'Boligrafo',3.5);
insert into producto(id,nombre,pvp)values(nextval('producto_seq'),'Lapiz',1.5);
insert into producto(id,nombre,pvp)values(nextval('producto_seq'),'Papel',0.5);