package com.example.ejercicio02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
