package com.example.ejerciciosdto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjerciciosdtoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjerciciosdtoApplication.class, args);
	}

}
