package com.example.monumentosV3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonumentosV3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
